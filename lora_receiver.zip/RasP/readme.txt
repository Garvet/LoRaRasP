LoRa_receiver - стартовый файл
print_LoRa_receiver - тот же файл, но отправляет в консоль, а не на сервер (для проверки)

Для работы docker-compose в файле docker-compose.yml в строчке пути файла:
volumes:
  - "/home/pi/GH/lora_receiver/text.txt:/home/pi/Documents/text.txt"
прописать путь к папке lora_receiver, в левой части пути:
  - "{путь}/lora_receiver/text.txt:/home/pi/Documents/text.txt"

Для работы нужно чтобы был включён SPI-модуль
Проверить можно введя в терминале 
ls /dev/
(или просто залезть в папку по указанному пути)
Если есть 'spidev0.0' и 'spidev0.1', то SPI включена.

Если их нет вводим в терминал
sudo raspi-config 
Далее выбираем: Interfacing options -> SPI -> Enabled
Если spidev сразу не появились - перезагружаемся.

Есть вариант изменения текстовых конфигураций вручную, но я не копался и не проверял.
